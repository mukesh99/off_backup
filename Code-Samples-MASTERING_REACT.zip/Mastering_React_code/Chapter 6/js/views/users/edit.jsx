"use strict";

import React from 'react';

export default React.createClass({
	render: function () {
		return (
			<form className="user-edit">
				user edit
			</form>
		);
	}
});
 

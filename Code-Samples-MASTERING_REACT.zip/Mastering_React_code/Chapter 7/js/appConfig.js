export default {
	pageSize: 10,
	apiRoot: '//localhost:3000',
	postSummaryLength: 512,
	loadTimeSimMs: 2000
};

"use strict";

import React   from 'react';

export default React.createClass({
	render: function () {
		return (
			<form className="login-form">
				login form
			</form>
		);
	}
});
 

"use strict";

import React   from 'react';

export default React.createClass({
	render: function () {
		return (
			<div className="user-view">
				user view
			</div>
		);
	}
});
 

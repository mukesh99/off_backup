"use strict";

import React   from 'react';

export default React.createClass({
	render: function () {
		return (
			<ul className="user-list">
				<li>user list</li>
			</ul>
		);
	}
});
 

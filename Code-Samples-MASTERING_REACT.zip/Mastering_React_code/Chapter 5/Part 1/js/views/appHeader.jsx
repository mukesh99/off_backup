"use strict";

import React   from 'react';

export default React.createClass({
	render: function () {
		return (
			<header className="app-header">
				app header
			</header>
		);
	}
});
 

"use strict";

import React   from 'react';

export default React.createClass({
	render: function () {
		return (
			<div className="post-list-view">
				post list view
			</div>
		);
	}
});
 

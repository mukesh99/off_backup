"use strict";

import React   from 'react';

export default React.createClass({
	render: function () {
		return (
			<form className="post-edit">
				post edit
			</form>
		);
	}
});
 

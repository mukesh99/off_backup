import React, {Component} from 'react';

class Footer extends Component{
    render(){
        return(
            <div className="footer">This is a footer area</div>
        )
            
        
    }
}
export default Footer;
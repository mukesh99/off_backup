import React, { Component } from 'react';

class Cart extends Component {
  render() {
    return (
      <p>
      This is cart section123443
      </p>
    );
  }
}

export default Cart;